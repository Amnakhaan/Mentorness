
-- To avoid any errors, check missing value / null value 
-- Q1. Write a code to check NULL values
SELECT *
FROM corona_virus_dataset
WHERE (Province IS NULL OR Country_Region IS NULL OR Latitude IS NULL OR Longitude IS NULL OR Date IS NULL OR Confirmed IS NULL OR Deaths IS NULL OR Recovered IS NULL);

--Q2. If NULL values are present, update them with zeros for all columns. 
SELECT *,
       ISNULL(Province, '0') AS updated_province,
       ISNULL(Country_Region, '0') AS updated_country,
       ISNULL(Latitude, 0) AS updated_latitude,
       ISNULL(Longitude, 0) AS updated_longitude,
       ISNULL(Date, '1970-01-01') AS updated_date,
       ISNULL(Confirmed, 0) AS updated_confirmed,
       ISNULL(Deaths, 0) AS updated_deaths,
       ISNULL(Recovered, 0) AS updated_recovered
FROM corona_virus_dataset;


-- Q3. check total number of rows
SELECT COUNT (*) as Total_rows
FROM corona_virus_dataset;


-- Q4. Check what is start_date and end_date
SELECT MIN(Date) AS start_date, MAX(Date) AS end_date
FROM corona_virus_dataset;


-- Q5. Number of month present in dataset
SELECT COUNT(DISTINCT SUBSTRING(Date,6,2)) AS number_of_months
FROM corona_virus_dataset;


-- Q6. Find monthly average for confirmed, deaths, recovered
SELECT SUBSTRING(Date,1,7) as monthly,
AVG(Confirmed) AS average_confirmed, AVG(Deaths) AS average_deaths, AVG(Recovered) AS average_recovered
FROM corona_virus_dataset
GROUP BY SUBSTRING(Date,1,7)
ORDER BY monthly;


-- Q7. Find most frequent value for confirmed, deaths, recovered each month
WITH MonthlyData AS (
    SELECT
        DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)) AS [Year],
        DATEPART(MONTH, TRY_CAST([Date] AS DATETIME)) AS [Month],
        Confirmed,
        Deaths,
        Recovered,
        COUNT(*) AS Frequency
    FROM [corona_virus_DB].[dbo].[corona_virus_dataset]
    GROUP BY DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)), DATEPART(MONTH, TRY_CAST([Date] AS DATETIME)), Confirmed, Deaths, Recovered
)
SELECT
    [Year],
    [Month],
    Confirmed,
    Deaths,
    Recovered
FROM (
    SELECT
        [Year],
        [Month],
        Confirmed,
        Deaths,
        Recovered,
        ROW_NUMBER() OVER (PARTITION BY [Year], [Month] ORDER BY Frequency DESC) AS rn
    FROM MonthlyData
) t
WHERE rn = 1;



-- Q8. Find minimum values for confirmed, deaths, recovered per year
SELECT
    DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)) AS [Year],
    MIN(Confirmed) AS MinConfirmed,
    MIN(Deaths) AS MinDeaths,
    MIN(Recovered) AS MinRecovered
FROM corona_virus_dataset
WHERE TRY_CAST([Date] AS DATETIME) IS NOT NULL
GROUP BY DATEPART(YEAR, TRY_CAST([Date] AS DATETIME));


-- Q9. Find maximum values of confirmed, deaths, recovered per year
SELECT
    DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)) AS [Year],
    MAX(Confirmed) AS MaxConfirmed,
    MAX(Deaths) AS MaxDeaths,
    MAX(Recovered) AS MaxRecovered
FROM corona_virus_dataset
WHERE TRY_CAST([Date] AS DATETIME) IS NOT NULL
GROUP BY  DATEPART(YEAR, TRY_CAST([Date] AS DATETIME));

-- Q10. The total number of cases of confirmed, deaths, recovered each month
SELECT
    DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)) AS [Year],
    DATEPART(MONTH, TRY_CAST([Date] AS datetime)) AS [Month],
    SUM(Confirmed) AS TotalConfirmed,
    SUM(Deaths) AS TotalDeaths,
    SUM(Recovered) AS TotalRecovered
FROM corona_virus_dataset
WHERE TRY_CAST([Date] AS DATETIME) IS NOT NULL
GROUP BY DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)), DATEPART(MONTH, TRY_CAST([Date] AS DATETIME));

-- Q11. Check how coronavirus spread out with respect to confirmed case
SELECT
    SUM(Confirmed) AS TotalConfirmed,
    AVG(Confirmed) AS AvgConfirmed,
    VAR(Confirmed) AS VarianceConfirmed,
    STDEV(Confirmed) AS StdDevConfirmed
FROM corona_virus_dataset;

-- Q12. Check how coronavirus spread out with respect to death case per month
SELECT
    DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)) AS [Year],
    DATEPART(MONTH, TRY_CAST([Date] AS DATETIME)) AS [Month],
    SUM(Deaths) AS TotalDeaths,
    AVG(Deaths) AS AvgDeaths,
    VAR(Deaths) AS VarianceDeaths,
    STDEV(Deaths) AS StdDevDeaths
FROM corona_virus_dataset
GROUP BY DATEPART(YEAR, TRY_CAST([Date] AS DATETIME)), DATEPART(MONTH, TRY_CAST([Date] AS DATETIME));

-- Q13. Check how coronavirus spread out with respect to recovered case
SELECT
    SUM(Recovered) AS TotalRecovered,
    AVG(Recovered) AS AvgRecovered,
    VAR(Recovered) AS VarianceRecovered,
    STDEV(Recovered) AS StdDevRecovered
FROM corona_virus_dataset;

-- Q14. Find Country having highest number of the confirmed case
SELECT TOP 1
    Country_Region,
    SUM(Confirmed) AS TotalConfirmed
FROM corona_virus_dataset
GROUP BY Country_Region
ORDER BY TotalConfirmed DESC;

-- Q15. Find Country having lowest number of the death case
SELECT TOP 1
    Country_Region,
    SUM(Deaths) AS TotalDeaths
FROM corona_virus_dataset
GROUP BY Country_Region
ORDER BY TotalDeaths ASC;

-- Q16. Find top 5 countries having highest recovered case
SELECT TOP 5
    Country_Region,
    SUM(Recovered) AS TotalRecovered
FROM corona_virus_dataset
GROUP BY Country_Region
ORDER BY TotalRecovered DESC;